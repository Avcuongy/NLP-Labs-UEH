API Listing
===========


This is an auto-generated listing of the PyEnchant API.

Full list
---------

* :ref:`API index <genindex>`

By module
---------

.. toctree::

   enchant.rst
   enchant.checker.rst
   enchant.errors.rst
   enchant.tokenize.rst
   enchant.utils.rst
   enchant.pypwl.rst
