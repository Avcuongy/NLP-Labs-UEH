
.. automodule:: enchant.utils
   :members:

