
.. automodule:: enchant.checker
   :members:

