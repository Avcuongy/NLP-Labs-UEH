
.. automodule:: enchant.errors
   :members:

